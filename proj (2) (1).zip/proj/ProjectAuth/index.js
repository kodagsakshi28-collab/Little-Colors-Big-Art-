// external module
const express = require('express');
const app = express();
const PORT = 3000;

app.use(express.urlencoded());

// local module
const { loginRouter } = require('./routes/loginRouter');
const { registerRouter } = require('./routes/registerRouter');
const { homeRouter } = require('./routes/homeRouter');

// set view engine
app.set('view engine', 'ejs');
app.set('views', 'views');


// Serve static files for CSS and JS
// app.use(express.static('../'));

app.use("/", loginRouter);
app.use("/", registerRouter);

// Home route
app.use('/', homeRouter);

// 404 handler
app.use((req, res) => {
    res.render('404');
});

app.listen(PORT, () => {
    console.log("app listen at http://localhost:3000");
})