const express = require('express');
const homeRouter = express.Router();

homeRouter.get('/', (req, res) => {
    res.redirect('http://127.0.0.1:5500/index.html');
});

module.exports = {
    homeRouter
};
