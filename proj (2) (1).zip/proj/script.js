const canvas = new fabric.Canvas('c', { backgroundColor: '#fffaf0' });
let drawingMode = '', startX, startY, tempObj;

const colorPicker = document.getElementById('colorPicker');
const bgPicker = document.getElementById('bgPicker');

let undoStack = [];
let redoStack = [];

function saveState() {
  undoStack.push(canvas.toJSON());
  redoStack = [];
}

// ===== Tool Buttons =====
document.getElementById('pencilBtn').onclick = () => {
  drawingMode = 'pencil';
  canvas.isDrawingMode = true;
  canvas.freeDrawingBrush.color = colorPicker.value;
};

document.getElementById('lineBtn').onclick = () => { drawingMode = 'line'; canvas.isDrawingMode = false; };
document.getElementById('rectBtn').onclick = () => { drawingMode = 'rect'; canvas.isDrawingMode = false; };
document.getElementById('squareBtn').onclick = () => { drawingMode = 'square'; canvas.isDrawingMode = false; };
document.getElementById('circleBtn').onclick = () => { drawingMode = 'circle'; canvas.isDrawingMode = false; };
document.getElementById('ellipseBtn').onclick = () => { drawingMode = 'ellipse'; canvas.isDrawingMode = false; };
document.getElementById('triangleBtn').onclick = () => { drawingMode = 'triangle'; canvas.isDrawingMode = false; };
document.getElementById('starBtn').onclick = () => { drawingMode = 'star'; canvas.isDrawingMode = false; };
document.getElementById('polygonBtn').onclick = () => { drawingMode = 'polygon'; canvas.isDrawingMode = false; };
document.getElementById('heartBtn').onclick = () => { drawingMode = 'heart'; canvas.isDrawingMode = false; };
document.getElementById('diamondBtn').onclick = () => { drawingMode = 'diamond'; canvas.isDrawingMode = false; };
document.getElementById('arrowBtn').onclick = () => { drawingMode = 'arrow'; canvas.isDrawingMode = false; };

document.getElementById('textBtn').onclick = () => {
  const text = new fabric.Textbox('Text here', {
    left: 100, top: 100, fontSize: 20, fill: colorPicker.value
  });
  canvas.add(text); saveState();
};

document.getElementById('eraserBtn').onclick = () => {
  drawingMode = 'eraser'; canvas.isDrawingMode = false;
};

document.getElementById('fillBtn').onclick = () => {
  const active = canvas.getActiveObject();
  if (active) { active.set('fill', colorPicker.value); canvas.renderAll(); saveState(); }
};

document.getElementById('undoBtn').onclick = () => {
  if (undoStack.length > 0) {
    redoStack.push(undoStack.pop());
    canvas.loadFromJSON(undoStack[undoStack.length - 1] || {}, () => canvas.renderAll());
  }
};

document.getElementById('redoBtn').onclick = () => {
  if (redoStack.length > 0) {
    const state = redoStack.pop();
    undoStack.push(state);
    canvas.loadFromJSON(state, () => canvas.renderAll());
  }
};

document.getElementById('clearBtn').onclick = () => {
  canvas.clear(); canvas.backgroundColor = bgPicker.value; saveState();
};

document.getElementById('saveBtn').onclick = () => {
  const dataURL = canvas.toDataURL({ format: 'png' });
  let saved = JSON.parse(localStorage.getItem('gallery') || '[]');
  saved.push(dataURL); localStorage.setItem('gallery', JSON.stringify(saved));
  alert('Saved to gallery!');
};

document.getElementById('galleryBtn').onclick = () => {
  document.getElementById('galleryPage').style.display = 'block';
  const container = document.getElementById('savedImages');
  container.innerHTML = '';
  let saved = JSON.parse(localStorage.getItem('gallery') || '[]');
  saved.forEach((img, i) => {
    const div = document.createElement('div');
    div.style.display = 'inline-block'; div.style.position = 'relative'; div.style.margin = '10px';
    const image = document.createElement('img');
    image.src = img; image.style.maxWidth = '150px'; image.style.border = '2px solid #000'; image.style.cursor = 'pointer';
    image.onclick = () => {
      fabric.Image.fromURL(img, function (oImg) {
        oImg.scaleToWidth(300); canvas.add(oImg); saveState();
      });
      document.getElementById('galleryPage').style.display = 'none';
    };
    const delBtn = document.createElement('button');
    delBtn.innerText = '❌'; delBtn.style.position = 'absolute'; delBtn.style.top = '0'; delBtn.style.right = '0';
    delBtn.onclick = () => {
      saved.splice(i, 1);
      localStorage.setItem('gallery', JSON.stringify(saved));
      div.remove();
    };
    div.appendChild(image); div.appendChild(delBtn); container.appendChild(div);
  });
};

document.getElementById('closeGalleryBtn').onclick = () => {
  document.getElementById('galleryPage').style.display = 'none';
};

bgPicker.onchange = () => { canvas.backgroundColor = bgPicker.value; canvas.renderAll(); saveState(); };

// ===== Drawing Shapes =====
canvas.on('mouse:down', function (o) {
  if (drawingMode && drawingMode !== 'pencil') {
    const pointer = canvas.getPointer(o.e);
    startX = pointer.x; startY = pointer.y;
    switch (drawingMode) {
      case 'line': tempObj = new fabric.Line([startX, startY, startX, startY], { stroke: colorPicker.value }); break;
      case 'rect': tempObj = new fabric.Rect({ left: startX, top: startY, width: 0, height: 0, fill: 'transparent', stroke: colorPicker.value }); break;
      case 'square': tempObj = new fabric.Rect({ left: startX, top: startY, width: 0, height: 0, fill: 'transparent', stroke: colorPicker.value }); break;
      case 'circle': tempObj = new fabric.Circle({ left: startX, top: startY, radius: 0, fill: 'transparent', stroke: colorPicker.value }); break;
      case 'ellipse': tempObj = new fabric.Ellipse({ left: startX, top: startY, rx: 0, ry: 0, fill: 'transparent', stroke: colorPicker.value }); break;
      case 'triangle': tempObj = new fabric.Triangle({ left: startX, top: startY, width: 0, height: 0, fill: 'transparent', stroke: colorPicker.value }); break;
      case 'star': tempObj = makeStar(startX, startY, 5, 0, 0, colorPicker.value); break;
      case 'polygon': tempObj = makePolygon(startX, startY, 6, 0, colorPicker.value); break;
      case 'heart': tempObj = makeHeart(startX, startY, 0, colorPicker.value); break;
      case 'diamond': tempObj = makeDiamond(startX, startY, 0, 0, colorPicker.value); break;
      case 'arrow': tempObj = makeArrow(startX, startY, 0, 0, colorPicker.value); break;
    }
    if (tempObj) canvas.add(tempObj);
  }
});

canvas.on('mouse:move', function (o) {
  if (!tempObj) return;
  const pointer = canvas.getPointer(o.e);
  const w = pointer.x - startX, h = pointer.y - startY;
  switch (drawingMode) {
    case 'line': tempObj.set({ x2: pointer.x, y2: pointer.y }); break;
    case 'rect': tempObj.set({ width: w, height: h }); break;
    case 'square': const side = Math.max(Math.abs(w), Math.abs(h)); tempObj.set({ width: side, height: side }); break;
    case 'circle': tempObj.set({ radius: Math.sqrt(w * w + h * h) / 2 }); break;
    case 'ellipse': tempObj.set({ rx: Math.abs(w / 2), ry: Math.abs(h / 2) }); break;
    case 'triangle': tempObj.set({ width: w, height: h }); break;
    case 'star': canvas.remove(tempObj); tempObj = makeStar(startX, startY, 5, w, h, colorPicker.value); canvas.add(tempObj); break;
    case 'polygon': canvas.remove(tempObj); tempObj = makePolygon(startX, startY, 6, w, colorPicker.value); canvas.add(tempObj); break;
    case 'heart': canvas.remove(tempObj); tempObj = makeHeart(startX, startY, Math.max(Math.abs(w), Math.abs(h)), colorPicker.value); canvas.add(tempObj); break;
    case 'diamond': canvas.remove(tempObj); tempObj = makeDiamond(startX, startY, w, h, colorPicker.value); canvas.add(tempObj); break;
    case 'arrow': canvas.remove(tempObj); tempObj = makeArrow(startX, startY, w, h, colorPicker.value); canvas.add(tempObj); break;
  }
  canvas.renderAll();
});

canvas.on('mouse:up', function () { if (tempObj) saveState(); tempObj = null; });

// ===== Shape Generators =====
function makeStar(x, y, points, w, h, color) {
  const outerR = Math.max(Math.abs(w), Math.abs(h)) / 2, innerR = outerR / 2;
  const angle = Math.PI / points, polyPoints = [];
  for (let i = 0; i < 2 * points; i++) {
    const r = (i % 2 === 0) ? outerR : innerR, a = i * angle;
    polyPoints.push({ x: x + r * Math.cos(a), y: y + r * Math.sin(a) });
  }
  return new fabric.Polygon(polyPoints, { fill: 'transparent', stroke: color });
}

function makePolygon(x, y, sides, r, color) {
  r = Math.abs(r);
  const pts = [];
  for (let i = 0; i < sides; i++) {
    const a = (i * 2 * Math.PI) / sides;
    pts.push({ x: x + r * Math.cos(a), y: y + r * Math.sin(a) });
  }
  return new fabric.Polygon(pts, { fill: 'transparent', stroke: color });
}

function makeHeart(x, y, size, color) {
  size = Math.abs(size) / 2;
  const path = `M ${x} ${y}
    C ${x} ${y - size}, ${x - size} ${y - size}, ${x - size} ${y}
    C ${x - size} ${y + size}, ${x} ${y + size}, ${x} ${y + 2 * size}
    C ${x} ${y + size}, ${x + size} ${y + size}, ${x + size} ${y}
    C ${x + size} ${y - size}, ${x} ${y - size}, ${x} ${y} Z`;
  return new fabric.Path(path, { fill: 'transparent', stroke: color });
}

function makeDiamond(x, y, w, h, color) {
  return new fabric.Polygon([
    { x: x, y: y - h / 2 },
    { x: x + w / 2, y: y },
    { x: x, y: y + h / 2 },
    { x: x - w / 2, y: y }
  ], { fill: 'transparent', stroke: color });
}

function makeArrow(x, y, w, h, color) {
  return new fabric.Polygon([
    { x: x, y: y - h / 4 }, { x: x + w / 2, y: y - h / 4 }, { x: x + w / 2, y: y - h / 2 },
    { x: x + w, y: y }, { x: x + w / 2, y: y + h / 2 }, { x: x + w / 2, y: y + h / 4 }, { x: x, y: y + h / 4 }
  ], { fill: 'transparent', stroke: color });
}

// ===== Delete / Cut button (fixed) =====
let deleteBtn = document.createElement('button');
deleteBtn.innerText = '✂';
Object.assign(deleteBtn.style, {
  position: 'absolute', display: 'none', zIndex: 1000,
  background: 'red', color: 'white', border: 'none',
  borderRadius: '50%', width: '30px', height: '30px',
  cursor: 'pointer', padding: '0'
});
document.body.appendChild(deleteBtn);

function hideDeleteBtn() { deleteBtn.style.display = 'none'; }
function positionDeleteBtn(obj) {
  if (!obj) return hideDeleteBtn();
  try { obj.setCoords(); } catch (e) { }
  const rect = (canvas.upperCanvasEl || canvas.getElement()).getBoundingClientRect();
  const tr = obj.oCoords && obj.oCoords.tr;
  if (tr) {
    deleteBtn.style.left = rect.left + tr.x - 15 + 'px';
    deleteBtn.style.top = rect.top + tr.y - 15 + 'px';
    deleteBtn.style.display = 'block';
  }
  else hideDeleteBtn();
}
canvas.on('selection:created', () => positionDeleteBtn(canvas.getActiveObject()));
canvas.on('selection:updated', () => positionDeleteBtn(canvas.getActiveObject()));
canvas.on('selection:cleared', hideDeleteBtn);
canvas.on('object:moving', () => positionDeleteBtn(canvas.getActiveObject()));
canvas.on('object:scaling', () => positionDeleteBtn(canvas.getActiveObject()));
canvas.on('object:rotating', () => positionDeleteBtn(canvas.getActiveObject()));
canvas.on('object:modified', () => positionDeleteBtn(canvas.getActiveObject()));
canvas.on('object:removed', hideDeleteBtn);

deleteBtn.onclick = (ev) => {
  ev.stopPropagation();
  const active = canvas.getActiveObject();
  if (active) { canvas.remove(active); hideDeleteBtn(); saveState(); }
};

// Keyboard delete
document.addEventListener('keydown', (e) => {
  if (['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName)) return;
  if (e.key === 'Delete' || e.key === 'Backspace') {
    const active = canvas.getActiveObject();
    if (active) { canvas.remove(active); hideDeleteBtn(); saveState(); }
  }
});
